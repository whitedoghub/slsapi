"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Constants = void 0;
const dotenv_1 = __importDefault(require("dotenv"));
switch (process.env.NODE_ENV) {
    case 'dev':
        dotenv_1.default.config({ path: './.env.dev' });
        break;
    case 'staging':
        dotenv_1.default.config({ path: './.env.staging' });
        break;
    case 'prod':
        dotenv_1.default.config({ path: './.env.prod' });
        break;
    default:
        dotenv_1.default.config();
}
dotenv_1.default.config();
const RUNNING_MODE = process.env.NODE_ENV;
const DB_CONFIG = {
    DB_URL: process.env['DB_URL']
};
exports.Constants = {
    DB_CONFIG, RUNNING_MODE
};
//# sourceMappingURL=Constants.js.map