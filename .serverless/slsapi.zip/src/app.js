"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.appHandler = void 0;
const koa_1 = __importDefault(require("koa"));
const koa_router_1 = __importDefault(require("koa-router"));
const koa_bodyparser_1 = __importDefault(require("koa-bodyparser"));
const cors_1 = __importDefault(require("@koa/cors"));
const dotenv_1 = __importDefault(require("dotenv"));
const serverless_http_1 = __importDefault(require("serverless-http"));
const api_1 = require("./api");
const app = new koa_1.default();
const router = new koa_router_1.default();
switch (process.env.NODE_ENV) {
    case 'local':
        dotenv_1.default.config({ path: './.env.dev' });
        break;
    case 'dev':
        dotenv_1.default.config({ path: './.env.dev' });
        break;
    case 'staging':
        dotenv_1.default.config({ path: './.env.staging' });
        break;
    case 'prod':
        dotenv_1.default.config({ path: './.env.prod' });
        break;
    default:
        dotenv_1.default.config();
}
app.use(cors_1.default());
router.use('/api', api_1.api.routes());
// router.get('/app/hello', (ctx: Koa.Context) => {
//     ctx.body = `DB_URL : ${process.env.DB_URL}`
//     // ctx.body = 'hello world....'
// })
app.use(koa_bodyparser_1.default()).use(router.routes()).use(router.allowedMethods());
if (process.env.NODE_ENV === 'local') {
    app.listen(4000, () => {
        console.log('listening');
    });
}
exports.appHandler = serverless_http_1.default(app);
//# sourceMappingURL=app.js.map