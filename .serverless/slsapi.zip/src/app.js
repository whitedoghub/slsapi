"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.appHandler = void 0;
const koa_1 = __importDefault(require("koa"));
const koa_router_1 = __importDefault(require("koa-router"));
const koa_bodyparser_1 = __importDefault(require("koa-bodyparser"));
const serverless_http_1 = __importDefault(require("serverless-http"));
const Constants_1 = require("./config/Constants");
const api_1 = require("./api");
const app = new koa_1.default();
const router = new koa_router_1.default();
router.use('/api', api_1.api.routes());
app.use(koa_bodyparser_1.default());
app.use(ctx => {
    ctx.body = `Request Body : ${JSON.stringify(ctx.request.body)}`;
});
app.use(router.routes()).use(router.allowedMethods());
if (Constants_1.Constants.RUNNING_MODE === 'local') {
    app.listen(4000, () => {
        console.log('listening');
    });
}
exports.appHandler = serverless_http_1.default(app);
//# sourceMappingURL=app.js.map