"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.books = void 0;
const koa_router_1 = __importDefault(require("koa-router"));
const BooksController_1 = require("./BooksController");
exports.books = new koa_router_1.default();
exports.books.get('/', BooksController_1.getBooks);
exports.books.get('/info/:version', BooksController_1.getBooksInfo);
exports.books.get('/dburl', BooksController_1.getDBURL);
exports.books.get('/testapi', BooksController_1.testAPIPoomGo);
exports.books.post('/postInfo', BooksController_1.postInfo);
//# sourceMappingURL=index.js.map