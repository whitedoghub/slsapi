"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.testAPIPoomGo = exports.postInfo = exports.getDBURL = exports.getBooks = exports.getBooksInfo = void 0;
const request_1 = __importDefault(require("request"));
const getBooksInfo = (ctx) => {
    ctx.status = 200;
    ctx.body = 'books info 109';
};
exports.getBooksInfo = getBooksInfo;
const getBooks = (ctx) => {
    const { version } = ctx.params;
    ctx.status = 200;
    ctx.body = `books api version : ${version}`;
};
exports.getBooks = getBooks;
const getDBURL = (ctx) => {
    ctx.status = 200;
    ctx.body = `DB URL = ${process.env.DB_URL}`;
};
exports.getDBURL = getDBURL;
const postInfo = (ctx) => {
    const info = ctx.request.body;
    ctx.body = info;
};
exports.postInfo = postInfo;
const testAPIPoomGo = (ctx) => {
    const option = {
        uri: 'https://open-api.poomgo.com/develop/master/list-partner-resources',
        method: 'POST',
        headers: {
            'accept': 'application/json',
            'Authorization': `${process.env.POOMGO_API_KEY}`
        }
    };
    request_1.default(option, function (err, response, body) {
        console.error('error: ', err);
        console.log('statusCode: ', response.statusCode);
        console.log('body: ', body);
        ctx.body = body;
    });
};
exports.testAPIPoomGo = testAPIPoomGo;
//# sourceMappingURL=BooksController.js.map