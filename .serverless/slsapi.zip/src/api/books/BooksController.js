"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.postInfo = exports.getDBURL = exports.getBooks = exports.getBooksInfo = void 0;
const getBooksInfo = (ctx) => {
    ctx.status = 200;
    ctx.body = 'books info 109';
};
exports.getBooksInfo = getBooksInfo;
const getBooks = (ctx) => {
    const { version } = ctx.params;
    ctx.status = 200;
    ctx.body = `books api version : ${version}`;
};
exports.getBooks = getBooks;
const getDBURL = (ctx) => {
    ctx.status = 200;
    ctx.body = `DB URL = ${process.env.DB_URL}`;
};
exports.getDBURL = getDBURL;
const postInfo = (ctx) => {
    const info = ctx.request.body;
    ctx.body = info;
};
exports.postInfo = postInfo;
//# sourceMappingURL=BooksController.js.map